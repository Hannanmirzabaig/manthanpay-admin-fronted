﻿// import ProfileSection from "./ProfileSection";
// import ProfileInfoItem from "./ProfileInfoItem";

// export default function SecurityInformation() {
//   return (
//     <ProfileSection
//       title="Security"
//       description="Security information related to your account."
//     >
//       <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
//         <ProfileInfoItem label="Two-Factor Authentication" value="" />
//         <ProfileInfoItem label="Last Password Change" value="" />
//         <ProfileInfoItem label="Last Login" value="" />
//         <ProfileInfoItem label="Active Sessions" value="" />
//       </div>
//       <p className="mt-5 rounded-lg bg-blue-50 p-3 text-xs text-blue-800">
//         Security details will be displayed after secure backend integration.
//       </p>
//     </ProfileSection>
//   );
// }
