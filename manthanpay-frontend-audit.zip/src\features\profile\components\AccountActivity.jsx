﻿// import ProfileSection from "./ProfileSection";
// import ProfileInfoItem from "./ProfileInfoItem";

// export default function AccountActivity() {
//   return (
//     <ProfileSection
//       title="Account Activity"
//       description="Important account creation and update information."
//     >
//       <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
//         <ProfileInfoItem label="Account Created" value="" />
//         <ProfileInfoItem label="Last Updated" value="" />
//         <ProfileInfoItem label="Created By" value="" />
//       </div>
//     </ProfileSection>
//   );
// }
