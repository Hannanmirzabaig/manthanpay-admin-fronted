﻿// import ProfileSection from "./ProfileSection";
// import ProfileInfoItem from "./ProfileInfoItem";

// export default function WorkInformation({ formattedRole }) {
//   return (
//     <ProfileSection
//       title="Work Information"
//       description="Your organization, department and assigned role details."
//     >
//       <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
//         <ProfileInfoItem label="Role" value={formattedRole} />
//         <ProfileInfoItem label="Department" value="" />
//         <ProfileInfoItem label="Designation" value="" />
//         <ProfileInfoItem label="Account Status" value="" />
//       </div>
//       <p className="mt-5 rounded-lg bg-blue-50 p-3 text-xs text-blue-800">
//         Work information will appear after secure backend integration.
//       </p>
//     </ProfileSection>
//   );
// }
